import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/pages/PurchasePage.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class ClientSelectionPage extends StatefulWidget {
  @override
  State<ClientSelectionPage> createState() => _ClientSelectionPageState();
}

class _ClientSelectionPageState extends State<ClientSelectionPage> {
  List<dynamic> clients = [];
  dynamic selectedClient;

  @override
  void initState() {
    super.initState();
    fetchClients();
  }

  Future<void> fetchClients() async {
    final response =
        await http.get(Uri.parse('http://192.168.1.105:8080/api/getClients'));
    if (response.statusCode == 200) {
      setState(() {
        clients = json.decode(response.body);
      });
    } else {
      throw Exception('Failed to load clients');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Client'),
      ),
      body: ListView.builder(
        itemCount: clients.length,
        itemBuilder: (BuildContext context, int index) {
          final client = clients[index];
          return ListTile(
            title: Text(client['commercialTitle']),
            onTap: () {
              setState(() {
                selectedClient = client;
              });
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      PurchasePage(selectedClient: selectedClient),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
